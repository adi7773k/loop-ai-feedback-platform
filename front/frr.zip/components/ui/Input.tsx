import { InputHTMLAttributes } from "react";

export default function Input({

className="",

...props

}:InputHTMLAttributes<HTMLInputElement>){

return(

<input

{...props}

className={`
w-full
rounded-2xl
border
border-slate-200
bg-white
px-5
py-3
text-sm
transition
focus:border-indigo-500
focus:ring-4
focus:ring-indigo-100
${className}
`}

/>

)

}
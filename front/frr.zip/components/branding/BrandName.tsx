interface BrandNameProps {
  compact?: boolean;
}

export default function BrandName({
  compact = false,
}: BrandNameProps) {
  return (
    <div className="leading-tight">
      <h1
        className={`font-bold tracking-tight ${
          compact
            ? "text-lg"
            : "text-2xl"
        }`}
      >
        LOOP
      </h1>

      {!compact && (
        <p className="text-xs text-slate-500">
          AI Feedback Intelligence
        </p>
      )}
    </div>
  );
}
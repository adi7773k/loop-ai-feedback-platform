interface LogoIconProps {
  className?: string;
}

export default function LogoIcon({
  className = "",
}: LogoIconProps) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient
          id="loopGradient"
          x1="0"
          y1="0"
          x2="64"
          y2="64"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#6366F1" />
          <stop offset="1" stopColor="#8B5CF6" />
        </linearGradient>
      </defs>

      {/* Background */}
      <rect
        x="6"
        y="6"
        width="52"
        height="52"
        rx="18"
        fill="url(#loopGradient)"
      />

      {/* L */}
      <path
        d="M22 18V42H42"
        stroke="white"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* AI Node */}
      <circle
        cx="42"
        cy="42"
        r="4"
        fill="white"
      />
    </svg>
  );
}